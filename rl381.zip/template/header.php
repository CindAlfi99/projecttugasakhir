<?php
require $_SERVER['DOCUMENT_ROOT'] . '/rl381/config/config.php';
?>

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="manifest" href="<?= BASE_URL; ?>manifest.json" />

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="<?= BASE_URL; ?>asset/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?= BASE_URL; ?>asset/css/landing.css">
	<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
	<link rel="icon" href="/favicon.ico" type="image/x-icon">
	<title>Rumah Laundry 381</title>
</head>