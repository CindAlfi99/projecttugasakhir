<?php 
$conn = mysqli_connect('localhost','root','','rumahlaundry381');

if (!$conn) {
  exit("Sorry, Connection error..");
}
?>