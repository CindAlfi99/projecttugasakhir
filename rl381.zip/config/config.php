<?php 
define('BASE_URL','http://localhost/rl381/');
$conn = mysqli_connect('localhost','root','','rumahlaundry381');

if (!$conn) {
  exit("Sorry, Connection error..");
}
?>