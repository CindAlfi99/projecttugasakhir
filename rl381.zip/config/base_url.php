<?php
define('BASE_URL','http://localhost/rl381/');
?>